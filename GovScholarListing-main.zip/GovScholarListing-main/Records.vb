﻿Imports MySql.Data.MySqlClient
Public Class Records

    Dim conn As New MySqlConnection
    Dim cmd As New MySqlCommand
    Dim cmdread As MySqlDataReader
    Dim selected_id As String

    Private Sub add_btn_Click(sender As Object, e As EventArgs) Handles add_btn.Click
        Dim str = "INSERT INTO `govsldbms`.`recordsinfo`
                    (`IDNum`,
                    `registration`,
                    `gwa`,
                    `MiscFee`)
                    VALUES (
                    '" & idTxtBox.Text & "',
                    '" & regTxtBox.Text & "',
                    '" & gwaTxtBox.Text & "',
                    '" & schoolFeesTxtBox.Text & "'
                    );"
        If readquery(str) Then
            MsgBox("New Recorded Added")
        Else
            MsgBox("Failed to Add Record.")
        End If

        Load_Table()
    End Sub
    Function readquery(sql As String) As Boolean
        Try
            With conn
                If .State = ConnectionState.Open Then .Close()
                .ConnectionString = "database=govsldbms;server=localhost;user id=root;Password=patricia;port=3307"
                .Open()
            End With
            With cmd
                .Connection = conn
                .CommandText = sql
                cmdread = .ExecuteReader
            End With
        Catch ex As Exception
            'MsgBox(ex.Message, MsgBoxStyle.Critical)
            Return False
        End Try
        conn.Close()
        Return True
    End Function

    Private Sub Load_Table() Handles Me.Load
        Dim table As New DataTable
        readquery("SELECT si.IDNum, si.StudentName, ri.registration, ri.gwa, ri.MiscFee
                    FROM govsldbms.studentinfo si
                  LEFT JOIN govsldbms.recordsinfo ri USING (IDNum)
        ;")
        Dim adapter As New MySqlDataAdapter(cmd)
        adapter.Fill(table)
        DataGridView1.DataSource = table
    End Sub
    Private Sub DataGrid_Select(sender As Object, e As EventArgs) Handles DataGridView1.SelectionChanged

        Try
            Dim selected = DataGridView1.Rows(DataGridView1.SelectedCells(0).RowIndex)
            idTxtBox.Text = selected.Cells(0).Value
            nameTxtBox.Text = selected.Cells(1).Value
            regTxtBox.Text = selected.Cells(2).Value
            gwaTxtBox.Text = selected.Cells(3).Value
            schoolFeesTxtBox.Text = selected.Cells(4).Value
            selected_id = selected.Cells(0).Value
        Catch ex As Exception

        End Try
    End Sub

    Private Sub UpD_btn_Click(sender As Object, e As EventArgs) Handles UpD_btn.Click
        Dim str = "UPDATE `govsldbms`.`recordsinfo`
                    SET
                    `IDNum` = '" & idTxtBox.Text & "',
                    `registration` = '" & regTxtBox.Text & "',
                    `gwa` = '" & gwaTxtBox.Text & "',
                    `MiscFee` = '" & schoolFeesTxtBox.Text & "'
                    WHERE `IDNum` = '" & selected_id & "';"

        If readquery(str) Then
            MsgBox("Record Updated")
        Else
            MsgBox("Failed to Update Record")
        End If


        Load_Table()
    End Sub

    Private Sub reset_btn_Click(sender As Object, e As EventArgs) Handles reset_btn.Click
        idTxtBox.Text = ""
        nameTxtBox.Text = ""
        regTxtBox.Text = ""
        gwaTxtBox.Text = ""
        schoolFeesTxtBox.Text = ""
    End Sub

    Private Sub delete_btn_Click(sender As Object, e As EventArgs) Handles delete_btn.Click
        Dim str = "DELETE 
                   FROM `govsldbms`.`recordsinfo`
                   WHERE IDNum= '" & selected_id & "';"
        If readquery(str) Then
            MsgBox("Record Deleted")
        Else
            MsgBox("Failed to Delete Record")
        End If


        Load_Table()
    End Sub

    Private Sub searchTxtBox_TextChanged(sender As Object, e As EventArgs) Handles searchTxtBox.TextChanged
        Dim search = searchTxtBox.Text
        Dim str = " SELECT si.IDNum, si.StudentName, ri.registration, ri.gwa, ri.MiscFee 
                    FROM govsldbms.studentinfo si
                    LEFT JOIN govsldbms.recordsinfo ri USING (IDNum)
                    WHERE IDNum LIKE '%" & search & "%' OR StudentName LIKE '%" & search & "%' OR gwa LIKE '%" & search & "%';"
        readquery(str)

        Dim table As New DataTable
        Dim adapter As New MySqlDataAdapter(cmd)
        adapter.Fill(table)
        DataGridView1.DataSource = table

    End Sub
End Class