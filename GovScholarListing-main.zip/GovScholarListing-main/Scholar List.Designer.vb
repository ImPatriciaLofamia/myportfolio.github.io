﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.inputPanel = New System.Windows.Forms.Panel()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.addressTxtBox = New System.Windows.Forms.MaskedTextBox()
        Me.addressLbl = New System.Windows.Forms.Label()
        Me.contactTxtBox = New System.Windows.Forms.MaskedTextBox()
        Me.contactLbl = New System.Windows.Forms.Label()
        Me.idTxtBox = New System.Windows.Forms.MaskedTextBox()
        Me.idLbl = New System.Windows.Forms.Label()
        Me.nameTxtBox = New System.Windows.Forms.MaskedTextBox()
        Me.nameLbl = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.reset_btn = New System.Windows.Forms.Button()
        Me.searchLbl = New System.Windows.Forms.Label()
        Me.searchTxtBox = New System.Windows.Forms.TextBox()
        Me.UpD_btn = New System.Windows.Forms.Button()
        Me.delete_btn = New System.Windows.Forms.Button()
        Me.add_btn = New System.Windows.Forms.Button()
        Me.inputPanel.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'inputPanel
        '
        Me.inputPanel.BackColor = System.Drawing.SystemColors.Control
        Me.inputPanel.Controls.Add(Me.DataGridView1)
        Me.inputPanel.Controls.Add(Me.addressTxtBox)
        Me.inputPanel.Controls.Add(Me.addressLbl)
        Me.inputPanel.Controls.Add(Me.contactTxtBox)
        Me.inputPanel.Controls.Add(Me.contactLbl)
        Me.inputPanel.Controls.Add(Me.idTxtBox)
        Me.inputPanel.Controls.Add(Me.idLbl)
        Me.inputPanel.Controls.Add(Me.nameTxtBox)
        Me.inputPanel.Controls.Add(Me.nameLbl)
        Me.inputPanel.Location = New System.Drawing.Point(-8, 1)
        Me.inputPanel.Name = "inputPanel"
        Me.inputPanel.Size = New System.Drawing.Size(567, 540)
        Me.inputPanel.TabIndex = 1
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AllowUserToOrderColumns = True
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(37, 198)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(0)
        Me.DataGridView1.MultiSelect = False
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.DataGridView1.RowTemplate.Height = 25
        Me.DataGridView1.Size = New System.Drawing.Size(509, 328)
        Me.DataGridView1.TabIndex = 26
        '
        'addressTxtBox
        '
        Me.addressTxtBox.Font = New System.Drawing.Font("Bernard MT Condensed", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.addressTxtBox.Location = New System.Drawing.Point(201, 146)
        Me.addressTxtBox.Name = "addressTxtBox"
        Me.addressTxtBox.Size = New System.Drawing.Size(345, 36)
        Me.addressTxtBox.TabIndex = 23
        '
        'addressLbl
        '
        Me.addressLbl.AutoSize = True
        Me.addressLbl.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.addressLbl.Location = New System.Drawing.Point(37, 149)
        Me.addressLbl.Name = "addressLbl"
        Me.addressLbl.Size = New System.Drawing.Size(151, 31)
        Me.addressLbl.TabIndex = 22
        Me.addressLbl.Text = "Home Address"
        '
        'contactTxtBox
        '
        Me.contactTxtBox.Font = New System.Drawing.Font("Bernard MT Condensed", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.contactTxtBox.Location = New System.Drawing.Point(201, 104)
        Me.contactTxtBox.Name = "contactTxtBox"
        Me.contactTxtBox.Size = New System.Drawing.Size(345, 36)
        Me.contactTxtBox.TabIndex = 19
        '
        'contactLbl
        '
        Me.contactLbl.AutoSize = True
        Me.contactLbl.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.contactLbl.Location = New System.Drawing.Point(37, 107)
        Me.contactLbl.Name = "contactLbl"
        Me.contactLbl.Size = New System.Drawing.Size(148, 31)
        Me.contactLbl.TabIndex = 18
        Me.contactLbl.Text = "Contact Num."
        '
        'idTxtBox
        '
        Me.idTxtBox.Font = New System.Drawing.Font("Bernard MT Condensed", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.idTxtBox.Location = New System.Drawing.Point(201, 62)
        Me.idTxtBox.Name = "idTxtBox"
        Me.idTxtBox.Size = New System.Drawing.Size(345, 36)
        Me.idTxtBox.TabIndex = 17
        '
        'idLbl
        '
        Me.idLbl.AutoSize = True
        Me.idLbl.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.idLbl.Location = New System.Drawing.Point(37, 65)
        Me.idLbl.Name = "idLbl"
        Me.idLbl.Size = New System.Drawing.Size(110, 31)
        Me.idLbl.TabIndex = 16
        Me.idLbl.Text = "ID Number"
        '
        'nameTxtBox
        '
        Me.nameTxtBox.Font = New System.Drawing.Font("Bernard MT Condensed", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nameTxtBox.Location = New System.Drawing.Point(201, 20)
        Me.nameTxtBox.Name = "nameTxtBox"
        Me.nameTxtBox.Size = New System.Drawing.Size(345, 36)
        Me.nameTxtBox.TabIndex = 15
        '
        'nameLbl
        '
        Me.nameLbl.AutoSize = True
        Me.nameLbl.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nameLbl.Location = New System.Drawing.Point(37, 23)
        Me.nameLbl.Name = "nameLbl"
        Me.nameLbl.Size = New System.Drawing.Size(153, 31)
        Me.nameLbl.TabIndex = 14
        Me.nameLbl.Text = "Student Name"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.Panel1.Controls.Add(Me.reset_btn)
        Me.Panel1.Controls.Add(Me.searchLbl)
        Me.Panel1.Controls.Add(Me.searchTxtBox)
        Me.Panel1.Controls.Add(Me.UpD_btn)
        Me.Panel1.Controls.Add(Me.delete_btn)
        Me.Panel1.Controls.Add(Me.add_btn)
        Me.Panel1.Location = New System.Drawing.Point(556, -1)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(271, 542)
        Me.Panel1.TabIndex = 2
        '
        'reset_btn
        '
        Me.reset_btn.FlatAppearance.BorderSize = 0
        Me.reset_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.reset_btn.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.reset_btn.ForeColor = System.Drawing.Color.White
        Me.reset_btn.Location = New System.Drawing.Point(0, 442)
        Me.reset_btn.Name = "reset_btn"
        Me.reset_btn.Size = New System.Drawing.Size(266, 100)
        Me.reset_btn.TabIndex = 7
        Me.reset_btn.Text = "Reset"
        Me.reset_btn.UseVisualStyleBackColor = True
        '
        'searchLbl
        '
        Me.searchLbl.AutoSize = True
        Me.searchLbl.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.searchLbl.ForeColor = System.Drawing.Color.White
        Me.searchLbl.Location = New System.Drawing.Point(9, 47)
        Me.searchLbl.Name = "searchLbl"
        Me.searchLbl.Size = New System.Drawing.Size(86, 31)
        Me.searchLbl.TabIndex = 5
        Me.searchLbl.Text = "Search"
        '
        'searchTxtBox
        '
        Me.searchTxtBox.Font = New System.Drawing.Font("Bernard MT Condensed", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.searchTxtBox.Location = New System.Drawing.Point(9, 78)
        Me.searchTxtBox.Name = "searchTxtBox"
        Me.searchTxtBox.Size = New System.Drawing.Size(248, 36)
        Me.searchTxtBox.TabIndex = 3
        '
        'UpD_btn
        '
        Me.UpD_btn.FlatAppearance.BorderSize = 0
        Me.UpD_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.UpD_btn.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.UpD_btn.ForeColor = System.Drawing.Color.White
        Me.UpD_btn.Location = New System.Drawing.Point(0, 346)
        Me.UpD_btn.Name = "UpD_btn"
        Me.UpD_btn.Size = New System.Drawing.Size(266, 100)
        Me.UpD_btn.TabIndex = 2
        Me.UpD_btn.Text = "Update"
        Me.UpD_btn.UseVisualStyleBackColor = True
        '
        'delete_btn
        '
        Me.delete_btn.FlatAppearance.BorderSize = 0
        Me.delete_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.delete_btn.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.delete_btn.ForeColor = System.Drawing.Color.White
        Me.delete_btn.Location = New System.Drawing.Point(0, 242)
        Me.delete_btn.Name = "delete_btn"
        Me.delete_btn.Size = New System.Drawing.Size(266, 100)
        Me.delete_btn.TabIndex = 1
        Me.delete_btn.Text = "Delete"
        Me.delete_btn.UseVisualStyleBackColor = True
        '
        'add_btn
        '
        Me.add_btn.FlatAppearance.BorderSize = 0
        Me.add_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.add_btn.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.add_btn.ForeColor = System.Drawing.Color.White
        Me.add_btn.Location = New System.Drawing.Point(0, 138)
        Me.add_btn.Name = "add_btn"
        Me.add_btn.Size = New System.Drawing.Size(266, 100)
        Me.add_btn.TabIndex = 0
        Me.add_btn.Text = "Add"
        Me.add_btn.UseVisualStyleBackColor = True
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(826, 539)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.inputPanel)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.inputPanel.ResumeLayout(False)
        Me.inputPanel.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents update_btn As Button
    Friend WithEvents inputPanel As Panel
    Friend WithEvents nameTxtBox As MaskedTextBox
    Friend WithEvents nameLbl As Label
    Friend WithEvents idTxtBox As MaskedTextBox
    Friend WithEvents idLbl As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents searchLbl As Label
    Friend WithEvents searchTxtBox As TextBox
    Friend WithEvents UpD_btn As Button
    Friend WithEvents delete_btn As Button
    Friend WithEvents add_btn As Button
    Friend WithEvents contactTxtBox As MaskedTextBox
    Friend WithEvents contactLbl As Label
    Friend WithEvents addressTxtBox As MaskedTextBox
    Friend WithEvents addressLbl As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents reset_btn As Button
End Class
