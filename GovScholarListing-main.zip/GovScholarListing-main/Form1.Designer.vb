﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.menuPnl = New System.Windows.Forms.Panel()
        Me.admin_btn = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.newApplicant_btn = New System.Windows.Forms.Button()
        Me.records_btn = New System.Windows.Forms.Button()
        Me.personalInfo_btn = New System.Windows.Forms.Button()
        Me.scholarList_btn = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.detailsPnl = New System.Windows.Forms.Panel()
        Me.menuPnl.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'menuPnl
        '
        Me.menuPnl.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.menuPnl.Controls.Add(Me.admin_btn)
        Me.menuPnl.Controls.Add(Me.Panel1)
        Me.menuPnl.Controls.Add(Me.newApplicant_btn)
        Me.menuPnl.Controls.Add(Me.records_btn)
        Me.menuPnl.Controls.Add(Me.personalInfo_btn)
        Me.menuPnl.Controls.Add(Me.scholarList_btn)
        Me.menuPnl.Controls.Add(Me.Label2)
        Me.menuPnl.Controls.Add(Me.Label1)
        Me.menuPnl.Location = New System.Drawing.Point(0, 0)
        Me.menuPnl.Name = "menuPnl"
        Me.menuPnl.Size = New System.Drawing.Size(357, 566)
        Me.menuPnl.TabIndex = 0
        '
        'admin_btn
        '
        Me.admin_btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.admin_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.admin_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.admin_btn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.admin_btn.FlatAppearance.BorderSize = 0
        Me.admin_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.admin_btn.Font = New System.Drawing.Font("Bebas", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.admin_btn.ForeColor = System.Drawing.Color.White
        Me.admin_btn.Location = New System.Drawing.Point(0, 465)
        Me.admin_btn.Name = "admin_btn"
        Me.admin_btn.Size = New System.Drawing.Size(360, 94)
        Me.admin_btn.TabIndex = 11
        Me.admin_btn.Text = "Administrators"
        Me.admin_btn.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(66, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.Panel1.Location = New System.Drawing.Point(19, 123)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(311, 8)
        Me.Panel1.TabIndex = 10
        '
        'newApplicant_btn
        '
        Me.newApplicant_btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.newApplicant_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.newApplicant_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.newApplicant_btn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.newApplicant_btn.FlatAppearance.BorderSize = 0
        Me.newApplicant_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.newApplicant_btn.Font = New System.Drawing.Font("Bebas", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.newApplicant_btn.ForeColor = System.Drawing.Color.White
        Me.newApplicant_btn.Location = New System.Drawing.Point(-2, 371)
        Me.newApplicant_btn.Name = "newApplicant_btn"
        Me.newApplicant_btn.Size = New System.Drawing.Size(360, 94)
        Me.newApplicant_btn.TabIndex = 9
        Me.newApplicant_btn.Text = "New Applicants"
        Me.newApplicant_btn.UseVisualStyleBackColor = False
        '
        'records_btn
        '
        Me.records_btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.records_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.records_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.records_btn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.records_btn.FlatAppearance.BorderSize = 0
        Me.records_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.records_btn.Font = New System.Drawing.Font("Bebas", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.records_btn.ForeColor = System.Drawing.Color.White
        Me.records_btn.Location = New System.Drawing.Point(-2, 294)
        Me.records_btn.Name = "records_btn"
        Me.records_btn.Size = New System.Drawing.Size(360, 94)
        Me.records_btn.TabIndex = 8
        Me.records_btn.Text = "Records"
        Me.records_btn.UseVisualStyleBackColor = False
        '
        'personalInfo_btn
        '
        Me.personalInfo_btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.personalInfo_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.personalInfo_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.personalInfo_btn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.personalInfo_btn.FlatAppearance.BorderSize = 0
        Me.personalInfo_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.personalInfo_btn.Font = New System.Drawing.Font("Bebas", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.personalInfo_btn.ForeColor = System.Drawing.Color.White
        Me.personalInfo_btn.Location = New System.Drawing.Point(0, 214)
        Me.personalInfo_btn.Name = "personalInfo_btn"
        Me.personalInfo_btn.Size = New System.Drawing.Size(358, 94)
        Me.personalInfo_btn.TabIndex = 7
        Me.personalInfo_btn.Text = "Guardian  Info"
        Me.personalInfo_btn.UseVisualStyleBackColor = False
        '
        'scholarList_btn
        '
        Me.scholarList_btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.scholarList_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.scholarList_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.scholarList_btn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.scholarList_btn.FlatAppearance.BorderSize = 0
        Me.scholarList_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.scholarList_btn.Font = New System.Drawing.Font("Bebas", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.scholarList_btn.ForeColor = System.Drawing.Color.White
        Me.scholarList_btn.Location = New System.Drawing.Point(0, 132)
        Me.scholarList_btn.Name = "scholarList_btn"
        Me.scholarList_btn.Size = New System.Drawing.Size(358, 94)
        Me.scholarList_btn.TabIndex = 6
        Me.scholarList_btn.Text = "Scholar Lists"
        Me.scholarList_btn.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label2.ForeColor = System.Drawing.Color.Cornsilk
        Me.Label2.Location = New System.Drawing.Point(67, 79)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(222, 31)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "MANAGEMENT SYSTEM"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Bebas", 19.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label1.ForeColor = System.Drawing.Color.Cornsilk
        Me.Label1.Location = New System.Drawing.Point(5, 36)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(345, 35)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "GOVERNMENT SCHOLAR-LISTING " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.Panel2.Controls.Add(Me.detailsPnl)
        Me.Panel2.Location = New System.Drawing.Point(344, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(853, 566)
        Me.Panel2.TabIndex = 1
        '
        'detailsPnl
        '
        Me.detailsPnl.BackColor = System.Drawing.SystemColors.Control
        Me.detailsPnl.Location = New System.Drawing.Point(12, 12)
        Me.detailsPnl.Name = "detailsPnl"
        Me.detailsPnl.Size = New System.Drawing.Size(826, 539)
        Me.detailsPnl.TabIndex = 0
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1194, 563)
        Me.Controls.Add(Me.menuPnl)
        Me.Controls.Add(Me.Panel2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Government Scholar-Listing Databse Management System"
        Me.menuPnl.ResumeLayout(False)
        Me.menuPnl.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents menuPnl As Panel
    Friend WithEvents scholarList_btn As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents newApplicant_btn As Button
    Friend WithEvents records_btn As Button
    Friend WithEvents personalInfo_btn As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents detailsPnl As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents admin_btn As Button
End Class
