﻿Imports MySql.Data.MySqlClient
Public Class Form2

    Dim conn As New MySqlConnection
    Dim cmd As New MySqlCommand
    Dim cmdread As MySqlDataReader
    Dim selected_id As String

    Private Sub add_btn_Click(sender As Object, e As EventArgs) Handles add_btn.Click
        Dim str = "INSERT INTO `govsldbms`.`studentinfo`
                    (`IDNum`,
                    `StudentName`,
                    `HomeAddress`,
                    `Cellphone`)
                    VALUES
                    ('" & idTxtBox.Text & "', 
                     '" & nameTxtBox.Text & "',
                     '" & addressTxtBox.Text & "',  
                     '" & contactTxtBox.Text & "'
                    );"
        If readquery(str) Then
            MsgBox("New Record Added")
        Else
            MsgBox("Failed to Add Record")
        End If

        Load_Table()

    End Sub

    Function readquery(sql As String) As Boolean
        Try
            With conn
                If .State = ConnectionState.Open Then .Close()
                .ConnectionString = "database=govsldbms;server=localhost;user id=root;Password=patricia;port=3307"
                .Open()
            End With
            With cmd
                .Connection = conn
                .CommandText = sql
                cmdread = .ExecuteReader
            End With
        Catch ex As Exception
            'MsgBox(ex.Message, MsgBoxStyle.Critical)
            Return False
        End Try
        conn.Close()
        Return True
    End Function

    Private Sub Load_Table() Handles Me.Load
        Dim table As New DataTable
        readquery("SELECT * FROM govsldbms.studentinfo")
        Dim adapter As New MySqlDataAdapter(cmd)
        adapter.Fill(table)
        DataGridView1.DataSource = table
    End Sub

    Private Sub DataGrid_Select(sender As Object, e As EventArgs) Handles DataGridView1.SelectionChanged

        Try
            Dim selected = DataGridView1.Rows(DataGridView1.SelectedCells(0).RowIndex)
            idTxtBox.Text = selected.Cells(0).Value
            nameTxtBox.Text = selected.Cells(1).Value
            addressTxtBox.Text = selected.Cells(2).Value
            contactTxtBox.Text = selected.Cells(3).Value

            selected_id = selected.Cells(0).Value
        Catch ex As Exception

        End Try
    End Sub

    Private Sub reset_btn_Click(sender As Object, e As EventArgs) Handles reset_btn.Click
        idTxtBox.Text = ""
        nameTxtBox.Text = ""
        addressTxtBox.Text = ""
        contactTxtBox.Text = ""
    End Sub

    Private Sub UpD_btn_Click(sender As Object, e As EventArgs) Handles UpD_btn.Click
        Dim str = "UPDATE `govsldbms`.`studentinfo`
                    SET
                    `IDNum` = '" & idTxtBox.Text & "',
                    `StudentName` = '" & nameTxtBox.Text & "',
                    `HomeAddress` = '" & addressTxtBox.Text & "',
                    `Cellphone` = '" & contactTxtBox.Text & "'
                    WHERE `IDNum` = '" & selected_id & "';"
        If readquery(str) Then
            MsgBox("Record Updated")
        Else
            MsgBox("Failed to update record")
        End If

        Load_Table()
    End Sub

    Private Sub delete_btn_Click(sender As Object, e As EventArgs) Handles delete_btn.Click
        Dim str = "DELETE 
                   FROM `govsldbms`.`studentinfo`
                   WHERE IDNum= '" & selected_id & "';"
        If readquery(str) Then
            MsgBox("Recorded Deleted")
        Else
            MsgBox("Failed to Delete REcord")
        End If

        Load_Table()
    End Sub

    Private Sub Search(sender As Object, e As EventArgs) Handles searchTxtBox.TextChanged
        Dim search = searchTxtBox.Text
        Dim str = " SELECT *
                FROM `govsldbms`.`studentinfo`
                WHERE IDNum LIKE '%" & search & "%' 
                OR StudentName LIKE '%" & search & "%' 
                OR HomeAddress LIKE '%" & search & "%';"
        readquery(str)

        Dim table As New DataTable
        Dim adapter As New MySqlDataAdapter(cmd)
        adapter.Fill(table)
        DataGridView1.DataSource = table

    End Sub
End Class