﻿Imports MySql.Data.MySqlClient

Module Functions
    Private conn As New MySqlConnection
    Private cmdReader As MySqlDataReader

    Function RunQuery(query As String)
        Connect()
        Dim cmd As New MySqlCommand(query, conn)
        Try
            cmdReader = cmd.ExecuteReader
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
        Return cmd
    End Function

    Sub Connect()
        Try
            With conn
                If .State Then .Close()
                .ConnectionString = ""
                .Open()
            End With
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

End Module
