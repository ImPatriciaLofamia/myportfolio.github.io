﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.reset_btn = New System.Windows.Forms.Button()
        Me.searchLbl = New System.Windows.Forms.Label()
        Me.searchTxtBox = New System.Windows.Forms.TextBox()
        Me.UpD_btn = New System.Windows.Forms.Button()
        Me.delete_btn = New System.Windows.Forms.Button()
        Me.add_btn = New System.Windows.Forms.Button()
        Me.guardianTxtBox = New System.Windows.Forms.MaskedTextBox()
        Me.guardianLbl = New System.Windows.Forms.Label()
        Me.nameTxtBox = New System.Windows.Forms.MaskedTextBox()
        Me.nameLbl = New System.Windows.Forms.Label()
        Me.HomeTxtBox = New System.Windows.Forms.MaskedTextBox()
        Me.HomeLbl = New System.Windows.Forms.Label()
        Me.guardianNumTxtBox = New System.Windows.Forms.MaskedTextBox()
        Me.gurdianNumLbl = New System.Windows.Forms.Label()
        Me.relationshipTxtBox = New System.Windows.Forms.MaskedTextBox()
        Me.relationshipLbl = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Panel1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.Panel1.Controls.Add(Me.reset_btn)
        Me.Panel1.Controls.Add(Me.searchLbl)
        Me.Panel1.Controls.Add(Me.searchTxtBox)
        Me.Panel1.Controls.Add(Me.UpD_btn)
        Me.Panel1.Controls.Add(Me.delete_btn)
        Me.Panel1.Controls.Add(Me.add_btn)
        Me.Panel1.Location = New System.Drawing.Point(557, -1)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(271, 542)
        Me.Panel1.TabIndex = 1
        '
        'reset_btn
        '
        Me.reset_btn.FlatAppearance.BorderSize = 0
        Me.reset_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.reset_btn.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.reset_btn.ForeColor = System.Drawing.Color.White
        Me.reset_btn.Location = New System.Drawing.Point(0, 442)
        Me.reset_btn.Name = "reset_btn"
        Me.reset_btn.Size = New System.Drawing.Size(266, 100)
        Me.reset_btn.TabIndex = 6
        Me.reset_btn.Text = "Reset"
        Me.reset_btn.UseVisualStyleBackColor = True
        '
        'searchLbl
        '
        Me.searchLbl.AutoSize = True
        Me.searchLbl.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.searchLbl.ForeColor = System.Drawing.Color.White
        Me.searchLbl.Location = New System.Drawing.Point(9, 47)
        Me.searchLbl.Name = "searchLbl"
        Me.searchLbl.Size = New System.Drawing.Size(86, 31)
        Me.searchLbl.TabIndex = 5
        Me.searchLbl.Text = "Search"
        '
        'searchTxtBox
        '
        Me.searchTxtBox.Font = New System.Drawing.Font("Bernard MT Condensed", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.searchTxtBox.Location = New System.Drawing.Point(9, 78)
        Me.searchTxtBox.Name = "searchTxtBox"
        Me.searchTxtBox.Size = New System.Drawing.Size(248, 36)
        Me.searchTxtBox.TabIndex = 3
        '
        'UpD_btn
        '
        Me.UpD_btn.FlatAppearance.BorderSize = 0
        Me.UpD_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.UpD_btn.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.UpD_btn.ForeColor = System.Drawing.Color.White
        Me.UpD_btn.Location = New System.Drawing.Point(0, 339)
        Me.UpD_btn.Name = "UpD_btn"
        Me.UpD_btn.Size = New System.Drawing.Size(266, 100)
        Me.UpD_btn.TabIndex = 2
        Me.UpD_btn.Text = "Update"
        Me.UpD_btn.UseVisualStyleBackColor = True
        '
        'delete_btn
        '
        Me.delete_btn.FlatAppearance.BorderSize = 0
        Me.delete_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.delete_btn.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.delete_btn.ForeColor = System.Drawing.Color.White
        Me.delete_btn.Location = New System.Drawing.Point(0, 227)
        Me.delete_btn.Name = "delete_btn"
        Me.delete_btn.Size = New System.Drawing.Size(266, 100)
        Me.delete_btn.TabIndex = 1
        Me.delete_btn.Text = "Delete"
        Me.delete_btn.UseVisualStyleBackColor = True
        '
        'add_btn
        '
        Me.add_btn.FlatAppearance.BorderSize = 0
        Me.add_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.add_btn.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.add_btn.ForeColor = System.Drawing.Color.White
        Me.add_btn.Location = New System.Drawing.Point(0, 117)
        Me.add_btn.Name = "add_btn"
        Me.add_btn.Size = New System.Drawing.Size(266, 100)
        Me.add_btn.TabIndex = 0
        Me.add_btn.Text = "Add"
        Me.add_btn.UseVisualStyleBackColor = True
        '
        'guardianTxtBox
        '
        Me.guardianTxtBox.Font = New System.Drawing.Font("Bernard MT Condensed", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.guardianTxtBox.Location = New System.Drawing.Point(192, 54)
        Me.guardianTxtBox.Name = "guardianTxtBox"
        Me.guardianTxtBox.Size = New System.Drawing.Size(345, 36)
        Me.guardianTxtBox.TabIndex = 11
        '
        'guardianLbl
        '
        Me.guardianLbl.AutoSize = True
        Me.guardianLbl.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.guardianLbl.Location = New System.Drawing.Point(28, 57)
        Me.guardianLbl.Name = "guardianLbl"
        Me.guardianLbl.Size = New System.Drawing.Size(161, 31)
        Me.guardianLbl.TabIndex = 10
        Me.guardianLbl.Text = "Guardian Name"
        '
        'nameTxtBox
        '
        Me.nameTxtBox.Font = New System.Drawing.Font("Bernard MT Condensed", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nameTxtBox.Location = New System.Drawing.Point(192, 12)
        Me.nameTxtBox.Name = "nameTxtBox"
        Me.nameTxtBox.Size = New System.Drawing.Size(345, 36)
        Me.nameTxtBox.TabIndex = 13
        '
        'nameLbl
        '
        Me.nameLbl.AutoSize = True
        Me.nameLbl.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nameLbl.Location = New System.Drawing.Point(28, 15)
        Me.nameLbl.Name = "nameLbl"
        Me.nameLbl.Size = New System.Drawing.Size(117, 31)
        Me.nameLbl.TabIndex = 12
        Me.nameLbl.Text = "Student ID"
        '
        'HomeTxtBox
        '
        Me.HomeTxtBox.Font = New System.Drawing.Font("Bernard MT Condensed", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.HomeTxtBox.Location = New System.Drawing.Point(192, 96)
        Me.HomeTxtBox.Name = "HomeTxtBox"
        Me.HomeTxtBox.Size = New System.Drawing.Size(345, 36)
        Me.HomeTxtBox.TabIndex = 15
        '
        'HomeLbl
        '
        Me.HomeLbl.AutoSize = True
        Me.HomeLbl.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.HomeLbl.Location = New System.Drawing.Point(28, 99)
        Me.HomeLbl.Name = "HomeLbl"
        Me.HomeLbl.Size = New System.Drawing.Size(151, 31)
        Me.HomeLbl.TabIndex = 14
        Me.HomeLbl.Text = "Home Address"
        '
        'guardianNumTxtBox
        '
        Me.guardianNumTxtBox.Font = New System.Drawing.Font("Bernard MT Condensed", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.guardianNumTxtBox.Location = New System.Drawing.Point(192, 138)
        Me.guardianNumTxtBox.Name = "guardianNumTxtBox"
        Me.guardianNumTxtBox.Size = New System.Drawing.Size(345, 36)
        Me.guardianNumTxtBox.TabIndex = 17
        '
        'gurdianNumLbl
        '
        Me.gurdianNumLbl.AutoSize = True
        Me.gurdianNumLbl.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.gurdianNumLbl.Location = New System.Drawing.Point(28, 141)
        Me.gurdianNumLbl.Name = "gurdianNumLbl"
        Me.gurdianNumLbl.Size = New System.Drawing.Size(148, 31)
        Me.gurdianNumLbl.TabIndex = 16
        Me.gurdianNumLbl.Text = "Contact Num."
        '
        'relationshipTxtBox
        '
        Me.relationshipTxtBox.Font = New System.Drawing.Font("Bernard MT Condensed", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.relationshipTxtBox.Location = New System.Drawing.Point(192, 180)
        Me.relationshipTxtBox.Name = "relationshipTxtBox"
        Me.relationshipTxtBox.Size = New System.Drawing.Size(345, 36)
        Me.relationshipTxtBox.TabIndex = 19
        '
        'relationshipLbl
        '
        Me.relationshipLbl.AutoSize = True
        Me.relationshipLbl.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.relationshipLbl.Location = New System.Drawing.Point(28, 183)
        Me.relationshipLbl.Name = "relationshipLbl"
        Me.relationshipLbl.Size = New System.Drawing.Size(145, 31)
        Me.relationshipLbl.TabIndex = 18
        Me.relationshipLbl.Text = "Relationship"
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AllowUserToOrderColumns = True
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(28, 226)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.RowTemplate.Height = 25
        Me.DataGridView1.Size = New System.Drawing.Size(509, 305)
        Me.DataGridView1.TabIndex = 20
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(826, 539)
        Me.ControlBox = False
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.relationshipTxtBox)
        Me.Controls.Add(Me.relationshipLbl)
        Me.Controls.Add(Me.guardianNumTxtBox)
        Me.Controls.Add(Me.gurdianNumLbl)
        Me.Controls.Add(Me.HomeTxtBox)
        Me.Controls.Add(Me.HomeLbl)
        Me.Controls.Add(Me.nameTxtBox)
        Me.Controls.Add(Me.nameLbl)
        Me.Controls.Add(Me.guardianTxtBox)
        Me.Controls.Add(Me.guardianLbl)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form3"
        Me.Text = "Form3"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents searchLbl As Label
    Friend WithEvents searchTxtBox As TextBox
    Friend WithEvents UpD_btn As Button
    Friend WithEvents delete_btn As Button
    Friend WithEvents add_btn As Button
    Friend WithEvents guardianTxtBox As MaskedTextBox
    Friend WithEvents guardianLbl As Label
    Friend WithEvents nameTxtBox As MaskedTextBox
    Friend WithEvents nameLbl As Label
    Friend WithEvents HomeTxtBox As MaskedTextBox
    Friend WithEvents HomeLbl As Label
    Friend WithEvents guardianNumTxtBox As MaskedTextBox
    Friend WithEvents gurdianNumLbl As Label
    Friend WithEvents relationshipTxtBox As MaskedTextBox
    Friend WithEvents relationshipLbl As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents reset_btn As Button
End Class
