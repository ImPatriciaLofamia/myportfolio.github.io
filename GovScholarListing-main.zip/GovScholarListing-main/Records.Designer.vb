﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Records
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.idLbl = New System.Windows.Forms.Label()
        Me.nameLbl = New System.Windows.Forms.Label()
        Me.regTxtBox = New System.Windows.Forms.MaskedTextBox()
        Me.registrationLbl = New System.Windows.Forms.Label()
        Me.gwaTxtBox = New System.Windows.Forms.MaskedTextBox()
        Me.GWALbl = New System.Windows.Forms.Label()
        Me.schoolFeesTxtBox = New System.Windows.Forms.MaskedTextBox()
        Me.schoolFeesLbl = New System.Windows.Forms.Label()
        Me.idTxtBox = New System.Windows.Forms.MaskedTextBox()
        Me.nameTxtBox = New System.Windows.Forms.MaskedTextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.reset_btn = New System.Windows.Forms.Button()
        Me.searchLbl = New System.Windows.Forms.Label()
        Me.searchTxtBox = New System.Windows.Forms.TextBox()
        Me.UpD_btn = New System.Windows.Forms.Button()
        Me.delete_btn = New System.Windows.Forms.Button()
        Me.add_btn = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Panel1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'idLbl
        '
        Me.idLbl.AutoSize = True
        Me.idLbl.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.idLbl.Location = New System.Drawing.Point(31, 53)
        Me.idLbl.Name = "idLbl"
        Me.idLbl.Size = New System.Drawing.Size(110, 31)
        Me.idLbl.TabIndex = 6
        Me.idLbl.Text = "ID Number"
        '
        'nameLbl
        '
        Me.nameLbl.AutoSize = True
        Me.nameLbl.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nameLbl.Location = New System.Drawing.Point(31, 15)
        Me.nameLbl.Name = "nameLbl"
        Me.nameLbl.Size = New System.Drawing.Size(153, 31)
        Me.nameLbl.TabIndex = 4
        Me.nameLbl.Text = "Student Name"
        '
        'regTxtBox
        '
        Me.regTxtBox.Font = New System.Drawing.Font("Bernard MT Condensed", 18.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.regTxtBox.Location = New System.Drawing.Point(195, 88)
        Me.regTxtBox.Name = "regTxtBox"
        Me.regTxtBox.Size = New System.Drawing.Size(345, 36)
        Me.regTxtBox.TabIndex = 9
        '
        'registrationLbl
        '
        Me.registrationLbl.AutoSize = True
        Me.registrationLbl.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.registrationLbl.Location = New System.Drawing.Point(31, 91)
        Me.registrationLbl.Name = "registrationLbl"
        Me.registrationLbl.Size = New System.Drawing.Size(146, 31)
        Me.registrationLbl.TabIndex = 8
        Me.registrationLbl.Text = "Registration"
        '
        'gwaTxtBox
        '
        Me.gwaTxtBox.Font = New System.Drawing.Font("Bernard MT Condensed", 18.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.gwaTxtBox.Location = New System.Drawing.Point(195, 127)
        Me.gwaTxtBox.Name = "gwaTxtBox"
        Me.gwaTxtBox.Size = New System.Drawing.Size(345, 36)
        Me.gwaTxtBox.TabIndex = 11
        '
        'GWALbl
        '
        Me.GWALbl.AutoSize = True
        Me.GWALbl.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.GWALbl.Location = New System.Drawing.Point(31, 130)
        Me.GWALbl.Name = "GWALbl"
        Me.GWALbl.Size = New System.Drawing.Size(57, 31)
        Me.GWALbl.TabIndex = 10
        Me.GWALbl.Text = "GWA"
        '
        'schoolFeesTxtBox
        '
        Me.schoolFeesTxtBox.Font = New System.Drawing.Font("Bernard MT Condensed", 18.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.schoolFeesTxtBox.Location = New System.Drawing.Point(195, 166)
        Me.schoolFeesTxtBox.Name = "schoolFeesTxtBox"
        Me.schoolFeesTxtBox.Size = New System.Drawing.Size(345, 36)
        Me.schoolFeesTxtBox.TabIndex = 13
        '
        'schoolFeesLbl
        '
        Me.schoolFeesLbl.AutoSize = True
        Me.schoolFeesLbl.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.schoolFeesLbl.Location = New System.Drawing.Point(31, 169)
        Me.schoolFeesLbl.Name = "schoolFeesLbl"
        Me.schoolFeesLbl.Size = New System.Drawing.Size(132, 31)
        Me.schoolFeesLbl.TabIndex = 12
        Me.schoolFeesLbl.Text = "School Fees"
        '
        'idTxtBox
        '
        Me.idTxtBox.Font = New System.Drawing.Font("Bernard MT Condensed", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.idTxtBox.Location = New System.Drawing.Point(195, 50)
        Me.idTxtBox.Name = "idTxtBox"
        Me.idTxtBox.Size = New System.Drawing.Size(345, 36)
        Me.idTxtBox.TabIndex = 7
        '
        'nameTxtBox
        '
        Me.nameTxtBox.Font = New System.Drawing.Font("Bernard MT Condensed", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nameTxtBox.Location = New System.Drawing.Point(195, 12)
        Me.nameTxtBox.Name = "nameTxtBox"
        Me.nameTxtBox.Size = New System.Drawing.Size(345, 36)
        Me.nameTxtBox.TabIndex = 5
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.Panel1.Controls.Add(Me.reset_btn)
        Me.Panel1.Controls.Add(Me.searchLbl)
        Me.Panel1.Controls.Add(Me.searchTxtBox)
        Me.Panel1.Controls.Add(Me.UpD_btn)
        Me.Panel1.Controls.Add(Me.delete_btn)
        Me.Panel1.Controls.Add(Me.add_btn)
        Me.Panel1.Location = New System.Drawing.Point(555, -1)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(271, 542)
        Me.Panel1.TabIndex = 16
        '
        'reset_btn
        '
        Me.reset_btn.FlatAppearance.BorderSize = 0
        Me.reset_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.reset_btn.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.reset_btn.ForeColor = System.Drawing.Color.White
        Me.reset_btn.Location = New System.Drawing.Point(-2, 442)
        Me.reset_btn.Name = "reset_btn"
        Me.reset_btn.Size = New System.Drawing.Size(266, 100)
        Me.reset_btn.TabIndex = 17
        Me.reset_btn.Text = "Reset"
        Me.reset_btn.UseVisualStyleBackColor = True
        '
        'searchLbl
        '
        Me.searchLbl.AutoSize = True
        Me.searchLbl.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.searchLbl.ForeColor = System.Drawing.Color.White
        Me.searchLbl.Location = New System.Drawing.Point(9, 47)
        Me.searchLbl.Name = "searchLbl"
        Me.searchLbl.Size = New System.Drawing.Size(86, 31)
        Me.searchLbl.TabIndex = 5
        Me.searchLbl.Text = "Search"
        '
        'searchTxtBox
        '
        Me.searchTxtBox.Font = New System.Drawing.Font("Bernard MT Condensed", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.searchTxtBox.Location = New System.Drawing.Point(9, 78)
        Me.searchTxtBox.Name = "searchTxtBox"
        Me.searchTxtBox.Size = New System.Drawing.Size(248, 36)
        Me.searchTxtBox.TabIndex = 3
        '
        'UpD_btn
        '
        Me.UpD_btn.FlatAppearance.BorderSize = 0
        Me.UpD_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.UpD_btn.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.UpD_btn.ForeColor = System.Drawing.Color.White
        Me.UpD_btn.Location = New System.Drawing.Point(0, 340)
        Me.UpD_btn.Name = "UpD_btn"
        Me.UpD_btn.Size = New System.Drawing.Size(266, 100)
        Me.UpD_btn.TabIndex = 2
        Me.UpD_btn.Text = "Update"
        Me.UpD_btn.UseVisualStyleBackColor = True
        '
        'delete_btn
        '
        Me.delete_btn.FlatAppearance.BorderSize = 0
        Me.delete_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.delete_btn.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.delete_btn.ForeColor = System.Drawing.Color.White
        Me.delete_btn.Location = New System.Drawing.Point(0, 238)
        Me.delete_btn.Name = "delete_btn"
        Me.delete_btn.Size = New System.Drawing.Size(266, 100)
        Me.delete_btn.TabIndex = 1
        Me.delete_btn.Text = "Delete"
        Me.delete_btn.UseVisualStyleBackColor = True
        '
        'add_btn
        '
        Me.add_btn.FlatAppearance.BorderSize = 0
        Me.add_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.add_btn.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.add_btn.ForeColor = System.Drawing.Color.White
        Me.add_btn.Location = New System.Drawing.Point(0, 139)
        Me.add_btn.Name = "add_btn"
        Me.add_btn.Size = New System.Drawing.Size(266, 100)
        Me.add_btn.TabIndex = 0
        Me.add_btn.Text = "Add"
        Me.add_btn.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(31, 208)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.RowTemplate.Height = 25
        Me.DataGridView1.Size = New System.Drawing.Size(509, 319)
        Me.DataGridView1.TabIndex = 6
        '
        'Records
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(826, 539)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.schoolFeesTxtBox)
        Me.Controls.Add(Me.schoolFeesLbl)
        Me.Controls.Add(Me.gwaTxtBox)
        Me.Controls.Add(Me.GWALbl)
        Me.Controls.Add(Me.regTxtBox)
        Me.Controls.Add(Me.registrationLbl)
        Me.Controls.Add(Me.idTxtBox)
        Me.Controls.Add(Me.idLbl)
        Me.Controls.Add(Me.nameTxtBox)
        Me.Controls.Add(Me.nameLbl)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Records"
        Me.Text = "Form4"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents idLbl As Label
    Friend WithEvents nameLbl As Label
    Friend WithEvents regTxtBox As MaskedTextBox
    Friend WithEvents registrationLbl As Label
    Friend WithEvents gwaTxtBox As MaskedTextBox
    Friend WithEvents GWALbl As Label
    Friend WithEvents schoolFeesTxtBox As MaskedTextBox
    Friend WithEvents schoolFeesLbl As Label
    Friend WithEvents idTxtBox As MaskedTextBox
    Friend WithEvents nameTxtBox As MaskedTextBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents searchLbl As Label
    Friend WithEvents searchTxtBox As TextBox
    Friend WithEvents UpD_btn As Button
    Friend WithEvents delete_btn As Button
    Friend WithEvents add_btn As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents reset_btn As Button
End Class
