﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form5
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.reset_btn = New System.Windows.Forms.Button()
        Me.searchLbl = New System.Windows.Forms.Label()
        Me.searchTxtBox = New System.Windows.Forms.TextBox()
        Me.UpD_btn = New System.Windows.Forms.Button()
        Me.delete_btn = New System.Windows.Forms.Button()
        Me.add_btn = New System.Windows.Forms.Button()
        Me.contactnumTxtBox = New System.Windows.Forms.MaskedTextBox()
        Me.cntactNumLbl = New System.Windows.Forms.Label()
        Me.gwaTxtBox = New System.Windows.Forms.MaskedTextBox()
        Me.GWALbl = New System.Windows.Forms.Label()
        Me.regTxtBox = New System.Windows.Forms.MaskedTextBox()
        Me.registrationLbl = New System.Windows.Forms.Label()
        Me.idTxtBox = New System.Windows.Forms.MaskedTextBox()
        Me.idLbl = New System.Windows.Forms.Label()
        Me.nameTxtBox = New System.Windows.Forms.MaskedTextBox()
        Me.nameLbl = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Panel1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.Panel1.Controls.Add(Me.reset_btn)
        Me.Panel1.Controls.Add(Me.searchLbl)
        Me.Panel1.Controls.Add(Me.searchTxtBox)
        Me.Panel1.Controls.Add(Me.UpD_btn)
        Me.Panel1.Controls.Add(Me.delete_btn)
        Me.Panel1.Controls.Add(Me.add_btn)
        Me.Panel1.Location = New System.Drawing.Point(555, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(271, 542)
        Me.Panel1.TabIndex = 28
        '
        'reset_btn
        '
        Me.reset_btn.FlatAppearance.BorderSize = 0
        Me.reset_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.reset_btn.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.reset_btn.ForeColor = System.Drawing.Color.White
        Me.reset_btn.Location = New System.Drawing.Point(3, 438)
        Me.reset_btn.Name = "reset_btn"
        Me.reset_btn.Size = New System.Drawing.Size(266, 100)
        Me.reset_btn.TabIndex = 30
        Me.reset_btn.Text = "Reset"
        Me.reset_btn.UseVisualStyleBackColor = True
        '
        'searchLbl
        '
        Me.searchLbl.AutoSize = True
        Me.searchLbl.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.searchLbl.ForeColor = System.Drawing.Color.White
        Me.searchLbl.Location = New System.Drawing.Point(9, 47)
        Me.searchLbl.Name = "searchLbl"
        Me.searchLbl.Size = New System.Drawing.Size(86, 31)
        Me.searchLbl.TabIndex = 5
        Me.searchLbl.Text = "Search"
        '
        'searchTxtBox
        '
        Me.searchTxtBox.Font = New System.Drawing.Font("Bernard MT Condensed", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.searchTxtBox.Location = New System.Drawing.Point(9, 78)
        Me.searchTxtBox.Name = "searchTxtBox"
        Me.searchTxtBox.Size = New System.Drawing.Size(248, 36)
        Me.searchTxtBox.TabIndex = 3
        '
        'UpD_btn
        '
        Me.UpD_btn.FlatAppearance.BorderSize = 0
        Me.UpD_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.UpD_btn.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.UpD_btn.ForeColor = System.Drawing.Color.White
        Me.UpD_btn.Location = New System.Drawing.Point(0, 346)
        Me.UpD_btn.Name = "UpD_btn"
        Me.UpD_btn.Size = New System.Drawing.Size(266, 100)
        Me.UpD_btn.TabIndex = 2
        Me.UpD_btn.Text = "Update"
        Me.UpD_btn.UseVisualStyleBackColor = True
        '
        'delete_btn
        '
        Me.delete_btn.FlatAppearance.BorderSize = 0
        Me.delete_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.delete_btn.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.delete_btn.ForeColor = System.Drawing.Color.White
        Me.delete_btn.Location = New System.Drawing.Point(0, 241)
        Me.delete_btn.Name = "delete_btn"
        Me.delete_btn.Size = New System.Drawing.Size(266, 100)
        Me.delete_btn.TabIndex = 1
        Me.delete_btn.Text = "Delete"
        Me.delete_btn.UseVisualStyleBackColor = True
        '
        'add_btn
        '
        Me.add_btn.FlatAppearance.BorderSize = 0
        Me.add_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.add_btn.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.add_btn.ForeColor = System.Drawing.Color.White
        Me.add_btn.Location = New System.Drawing.Point(0, 129)
        Me.add_btn.Name = "add_btn"
        Me.add_btn.Size = New System.Drawing.Size(266, 100)
        Me.add_btn.TabIndex = 0
        Me.add_btn.Text = "Add"
        Me.add_btn.UseVisualStyleBackColor = True
        '
        'contactnumTxtBox
        '
        Me.contactnumTxtBox.Font = New System.Drawing.Font("Bernard MT Condensed", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.contactnumTxtBox.Location = New System.Drawing.Point(193, 165)
        Me.contactnumTxtBox.Name = "contactnumTxtBox"
        Me.contactnumTxtBox.Size = New System.Drawing.Size(345, 36)
        Me.contactnumTxtBox.TabIndex = 26
        '
        'cntactNumLbl
        '
        Me.cntactNumLbl.AutoSize = True
        Me.cntactNumLbl.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.cntactNumLbl.Location = New System.Drawing.Point(31, 168)
        Me.cntactNumLbl.Name = "cntactNumLbl"
        Me.cntactNumLbl.Size = New System.Drawing.Size(148, 31)
        Me.cntactNumLbl.TabIndex = 25
        Me.cntactNumLbl.Text = "Contact Num."
        '
        'gwaTxtBox
        '
        Me.gwaTxtBox.Font = New System.Drawing.Font("Bernard MT Condensed", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.gwaTxtBox.Location = New System.Drawing.Point(193, 126)
        Me.gwaTxtBox.Name = "gwaTxtBox"
        Me.gwaTxtBox.Size = New System.Drawing.Size(345, 36)
        Me.gwaTxtBox.TabIndex = 24
        '
        'GWALbl
        '
        Me.GWALbl.AutoSize = True
        Me.GWALbl.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.GWALbl.Location = New System.Drawing.Point(31, 129)
        Me.GWALbl.Name = "GWALbl"
        Me.GWALbl.Size = New System.Drawing.Size(57, 31)
        Me.GWALbl.TabIndex = 23
        Me.GWALbl.Text = "GWA"
        '
        'regTxtBox
        '
        Me.regTxtBox.Font = New System.Drawing.Font("Bernard MT Condensed", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.regTxtBox.Location = New System.Drawing.Point(193, 87)
        Me.regTxtBox.Name = "regTxtBox"
        Me.regTxtBox.Size = New System.Drawing.Size(345, 36)
        Me.regTxtBox.TabIndex = 22
        '
        'registrationLbl
        '
        Me.registrationLbl.AutoSize = True
        Me.registrationLbl.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.registrationLbl.Location = New System.Drawing.Point(31, 92)
        Me.registrationLbl.Name = "registrationLbl"
        Me.registrationLbl.Size = New System.Drawing.Size(146, 31)
        Me.registrationLbl.TabIndex = 21
        Me.registrationLbl.Text = "Registration"
        '
        'idTxtBox
        '
        Me.idTxtBox.Font = New System.Drawing.Font("Bernard MT Condensed", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.idTxtBox.Location = New System.Drawing.Point(193, 49)
        Me.idTxtBox.Name = "idTxtBox"
        Me.idTxtBox.Size = New System.Drawing.Size(345, 36)
        Me.idTxtBox.TabIndex = 20
        '
        'idLbl
        '
        Me.idLbl.AutoSize = True
        Me.idLbl.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.idLbl.Location = New System.Drawing.Point(33, 51)
        Me.idLbl.Name = "idLbl"
        Me.idLbl.Size = New System.Drawing.Size(110, 31)
        Me.idLbl.TabIndex = 19
        Me.idLbl.Text = "ID Number"
        '
        'nameTxtBox
        '
        Me.nameTxtBox.Font = New System.Drawing.Font("Bernard MT Condensed", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nameTxtBox.Location = New System.Drawing.Point(193, 11)
        Me.nameTxtBox.Name = "nameTxtBox"
        Me.nameTxtBox.Size = New System.Drawing.Size(345, 36)
        Me.nameTxtBox.TabIndex = 18
        '
        'nameLbl
        '
        Me.nameLbl.AutoSize = True
        Me.nameLbl.Font = New System.Drawing.Font("Bebas", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nameLbl.Location = New System.Drawing.Point(32, 14)
        Me.nameLbl.Name = "nameLbl"
        Me.nameLbl.Size = New System.Drawing.Size(153, 31)
        Me.nameLbl.TabIndex = 17
        Me.nameLbl.Text = "Student Name"
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(31, 207)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.RowTemplate.Height = 25
        Me.DataGridView1.Size = New System.Drawing.Size(507, 320)
        Me.DataGridView1.TabIndex = 29
        '
        'Form5
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(826, 539)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.contactnumTxtBox)
        Me.Controls.Add(Me.cntactNumLbl)
        Me.Controls.Add(Me.gwaTxtBox)
        Me.Controls.Add(Me.GWALbl)
        Me.Controls.Add(Me.regTxtBox)
        Me.Controls.Add(Me.registrationLbl)
        Me.Controls.Add(Me.idTxtBox)
        Me.Controls.Add(Me.idLbl)
        Me.Controls.Add(Me.nameTxtBox)
        Me.Controls.Add(Me.nameLbl)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form5"
        Me.Text = "Form5"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As Panel
    Friend WithEvents searchLbl As Label
    Friend WithEvents searchTxtBox As TextBox
    Friend WithEvents UpD_btn As Button
    Friend WithEvents delete_btn As Button
    Friend WithEvents add_btn As Button
    Friend WithEvents contactnumTxtBox As MaskedTextBox
    Friend WithEvents cntactNumLbl As Label
    Friend WithEvents gwaTxtBox As MaskedTextBox
    Friend WithEvents GWALbl As Label
    Friend WithEvents regTxtBox As MaskedTextBox
    Friend WithEvents registrationLbl As Label
    Friend WithEvents idTxtBox As MaskedTextBox
    Friend WithEvents idLbl As Label
    Friend WithEvents nameTxtBox As MaskedTextBox
    Friend WithEvents nameLbl As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents reset_btn As Button
End Class
