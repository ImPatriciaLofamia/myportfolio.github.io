﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub switchPanel(panel As Form)
        detailsPnl.Controls.Clear()
        panel.TopLevel = False
        detailsPnl.Controls.Add(panel)
        panel.Show()
    End Sub

    Private Sub personalInfo_btn_Click(sender As Object, e As EventArgs) Handles personalInfo_btn.Click
        switchPanel(Form3)
    End Sub

    Private Sub records_btn_Click(sender As Object, e As EventArgs) Handles records_btn.Click
        switchPanel(Records)
    End Sub

    Private Sub newApplicant_btn_Click(sender As Object, e As EventArgs) Handles newApplicant_btn.Click
        switchPanel(Form5)
    End Sub

    Private Sub scholarList_btn_Click(sender As Object, e As EventArgs) Handles scholarList_btn.Click
        switchPanel(Form2)
    End Sub

    Private Sub admin_btn_Click(sender As Object, e As EventArgs) Handles admin_btn.Click
        switchPanel(Admins)

    End Sub
End Class
