﻿Imports MySql.Data.MySqlClient
Public Class Form3

    Dim conn As New MySqlConnection
    Dim cmd As New MySqlCommand
    Dim cmdread As MySqlDataReader
    Dim selected_id As String



    Private Sub add_btn_Click(sender As Object, e As EventArgs) Handles add_btn.Click
        Dim str = "INSERT INTO `govsldbms`.`guardianinfo`
                    (
                    `IDNum`,
                    `Guardian`,
                    `HomeAddress`,
                    `ContactNum`,
                    `Relationship`)
                    VALUES(
                        '" & nameTxtBox.Text & "',
                        '" & guardianTxtBox.Text & "',
                        '" & HomeTxtBox.Text & "',
                        '" & guardianNumTxtBox.Text & "',
                        '" & relationshipTxtBox.Text & "'
                    );"

        If readquery(str) Then
            MsgBox("New Record Added")
        Else
            MsgBox("Failed to add  record.")
        End If


        Load_Table()
    End Sub
    Function readquery(sql As String) As Boolean
        Try
            With conn
                If .State = ConnectionState.Open Then .Close()
                .ConnectionString = "database=govsldbms;server=localhost;user id=root;Password=patricia;port=3307"
                .Open()
            End With
            With cmd
                .Connection = conn
                .CommandText = sql
                cmdread = .ExecuteReader
            End With
        Catch ex As Exception
            'MsgBox(ex.Message, MsgBoxStyle.Critical)
            Return False
        End Try
        conn.Close()
        Return True
    End Function

    Private Sub Load_Table() Handles Me.Load
        Dim table As New DataTable
        readquery("SELECT si.StudentName,si.IDNum,gi.Guardian,gi.HomeAddress,gi.ContactNum,gi.Relationship FROM govsldbms.studentinfo si
                   LEFT JOIN govsldbms.guardianinfo gi USING (IDNum)
        ;")
        Dim adapter As New MySqlDataAdapter(cmd)
        adapter.Fill(table)
        DataGridView1.DataSource = table
    End Sub
    Private Sub DataGrid_Select(sender As Object, e As EventArgs) Handles DataGridView1.SelectionChanged


        Try
            Dim selected = DataGridView1.Rows(DataGridView1.SelectedCells(0).RowIndex)
            nameTxtBox.Text = selected.Cells(1).Value
            guardianTxtBox.Text = selected.Cells(2).Value
            HomeTxtBox.Text = selected.Cells(3).Value
            guardianNumTxtBox.Text = selected.Cells(4).Value
            relationshipTxtBox.Text = selected.Cells(5).Value

            selected_id = selected.Cells(1).Value
        Catch ex As Exception

        End Try
    End Sub

    Private Sub UpD_btn_Click(sender As Object, e As EventArgs) Handles UpD_btn.Click
        Dim str = "UPDATE `govsldbms`.`guardianinfo`
                    SET
                    `IDNum` = '" & nameTxtBox.Text & "',
                    `Guardian` = '" & guardianTxtBox.Text & "',
                    `HomeAddress` = '" & HomeTxtBox.Text & "',
                    `ContactNum` = '" & guardianNumTxtBox.Text & "',
                    `Relationship` = '" & relationshipTxtBox.Text & "'
                    WHERE `IDNum` = '" & selected_id & "' ;"
        If (readquery(str)) Then
            MsgBox("Record Updated.")
        Else
            MsgBox("Failed to update record.")
        End If

        Load_Table()

    End Sub

    Private Sub delete_btn_Click(sender As Object, e As EventArgs) Handles delete_btn.Click
        Dim str = "DELETE 
                   FROM `govsldbms`.`guardianinfo`
                   WHERE IDNum= '" & selected_id & "';"

        If (readquery(str)) Then
            MsgBox("Record Deleted.")
        Else
            MsgBox("Failed to delete record.")
        End If


        Load_Table()
    End Sub


    Private Sub searchTxtBox_TextChanged(sender As Object, e As EventArgs) Handles searchTxtBox.TextChanged
        Dim search = searchTxtBox.Text
        Dim str = " SELECT si.StudentName,si.IDNum,gi.Guardian,gi.HomeAddress,gi.ContactNum,gi.Relationship FROM govsldbms.studentinfo si
                   LEFT JOIN govsldbms.guardianinfo gi USING (IDNum)
                    WHERE IDNum LIKE '%" & search & "%' OR Guardian LIKE '%" & search & "%' OR StudentName LIKE '%" & search & "%' ;"
        readquery(str)

        Dim table As New DataTable
        Dim adapter As New MySqlDataAdapter(cmd)
        adapter.Fill(table)
        DataGridView1.DataSource = table
    End Sub

    Private Sub reset_btn_Click(sender As Object, e As EventArgs) Handles reset_btn.Click
        guardianTxtBox.Text = ""
        HomeTxtBox.Text = ""
        guardianNumTxtBox.Text = ""
        relationshipTxtBox.Text = ""
        nameTxtBox.Text = ""
    End Sub
End Class